package id.ac.polbeng.projectuts.ui.dashboard

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import id.ac.polbeng.projectuts.R
import id.ac.polbeng.projectuts.model.Product

class DetailProductActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PRODUCT = "extra_product"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_product)

        // Ambil data Serializable product
        val product = intent.getSerializableExtra(EXTRA_PRODUCT) as? Product

        if (product != null) {
            val imgDetail = findViewById<ImageView>(R.id.imgProductDetail)
            val tvTitle = findViewById<TextView>(R.id.tvDetailTitle)
            val tvPrice = findViewById<TextView>(R.id.tvDetailPrice)
            val tvCategory = findViewById<TextView>(R.id.tvDetailCategory)
            val tvStatus = findViewById<TextView>(R.id.tvDetailStatus)
            val tvStockRating = findViewById<TextView>(R.id.tvDetailStockRating)
            val tvDimensions = findViewById<TextView>(R.id.tvDetailDimensions)
            val tvTags = findViewById<TextView>(R.id.tvDetailTags)
            val tvDescription = findViewById<TextView>(R.id.tvDetailDescription)

            val tvReviewerName = findViewById<TextView>(R.id.tvReviewerName)
            val tvReviewComment = findViewById<TextView>(R.id.tvReviewComment)
            val tvSeeAllReviews = findViewById<TextView>(R.id.tvSeeAllReviews)

            tvTitle.text = "ID: ${product.id}\n${product.title}"
            tvPrice.text = "$${product.price}"
            tvCategory.text = "Kategori: ${product.category}"
            tvStatus.text = "Status: ${product.availabilityStatus}"
            tvStockRating.text = "Stok: ${product.stock} | Rating: ⭐ ${product.rating}"

            val dim = product.dimensions
            tvDimensions.text = "Dimensi: ${dim?.width} x ${dim?.height} x ${dim?.depth} cm"
            tvTags.text = "Tags: ${product.tags.joinToString(", ")}"
            tvDescription.text = product.description

            // Tampilkan gambar dari list images (sesuai kriteria poin F)
            val imageUrl = product.images.firstOrNull() ?: product.thumbnail
            Glide.with(this)
                .load(imageUrl)
                .into(imgDetail)

            // Tampilkan 1 review teratas (kriteria poin G)
            val firstReview = product.reviews?.firstOrNull()
            if (firstReview != null) {
                tvReviewerName.text = "${firstReview.reviewerName} (⭐ ${firstReview.rating})"
                tvReviewComment.text = "\"${firstReview.comment}\""
            } else {
                tvReviewerName.text = "Belum ada ulasan"
                tvReviewComment.text = "-"
            }

            // Dialog untuk menampilkan semua review
            tvSeeAllReviews.setOnClickListener {
                showAllReviewsDialog(product)
            }
        }
    }

    private fun showAllReviewsDialog(product: Product) {
        val reviewsText = product.reviews?.joinToString("\n\n") { review ->
            "👤 ${review.reviewerName} (⭐ ${review.rating})\n💬 \"${review.comment}\"\n📅 ${review.date}"
        } ?: "Tidak ada ulasan."

        AlertDialog.Builder(this)
            .setTitle("Semua Ulasan - ${product.title}")
            .setMessage(reviewsText)
            .setPositiveButton("Tutup") { dialog, _ -> dialog.dismiss() }
            .show()
    }
}
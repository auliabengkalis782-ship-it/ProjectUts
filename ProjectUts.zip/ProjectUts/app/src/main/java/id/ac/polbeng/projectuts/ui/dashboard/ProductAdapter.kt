package id.ac.polbeng.projectuts.ui.dashboard

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import id.ac.polbeng.projectuts.R
import id.ac.polbeng.projectuts.model.Product

class ProductAdapter(
    private val productList: List<Product>,
    private val clickListener: (Product) -> Unit
) : RecyclerView.Adapter<ProductAdapter.ProductViewHolder>() {

    class ProductViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imgThumbnail: ImageView = itemView.findViewById(R.id.imgThumbnail)
        val tvTitle: TextView = itemView.findViewById(R.id.tvTitle)
        val tvPrice: TextView = itemView.findViewById(R.id.tvPrice)
        val tvStock: TextView = itemView.findViewById(R.id.tvStock)
        val tvRating: TextView = itemView.findViewById(R.id.tvRating)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_product, parent, false)
        return ProductViewHolder(view)
    }

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        val product = productList[position]
        holder.tvTitle.text = product.title
        holder.tvPrice.text = "$${product.price}"
        holder.tvStock.text = "Stock: ${product.stock}"
        holder.tvRating.text = "${product.rating}"

        // Memuat gambar dari URL thumbnail menggunakan Glide
        Glide.with(holder.itemView.context)
            .load(product.thumbnail)
            .placeholder(R.drawable.profile_circle)
            .into(holder.imgThumbnail)

        // Event klik pada item produk
        holder.itemView.setOnClickListener {
            clickListener(product)
        }
    }

    override fun getItemCount(): Int = productList.size
}
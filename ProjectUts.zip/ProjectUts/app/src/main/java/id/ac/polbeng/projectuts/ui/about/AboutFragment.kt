package id.ac.polbeng.projectuts.ui.about

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import id.ac.polbeng.projectuts.R

class AboutFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Baris ini yang berfungsi menghubungkan Fragment ke file layout fragment_about.xml
        return inflater.inflate(R.layout.fragment_about, container, false)
    }
}
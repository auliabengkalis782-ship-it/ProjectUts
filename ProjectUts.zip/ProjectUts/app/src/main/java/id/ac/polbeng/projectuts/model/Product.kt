package id.ac.polbeng.projectuts.model

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class Product(
    @SerializedName("id")
    val id: Int,

    @SerializedName("title")
    val title: String,

    @SerializedName("description")
    val description: String,

    @SerializedName("category")
    val category: String,

    @SerializedName("price")
    val price: Double,

    @SerializedName("stock")
    val stock: Int,

    @SerializedName("availabilityStatus")
    val availabilityStatus: String,

    @SerializedName("rating")
    val rating: Double,

    @SerializedName("thumbnail")
    val thumbnail: String,

    @SerializedName("images")
    val images: List<String>,

    @SerializedName("tags")
    val tags: List<String>,

    @SerializedName("dimensions")
    val dimensions: Dimensions?,

    @SerializedName("reviews")
    val reviews: List<Review>?
) : Serializable

data class Dimensions(
    @SerializedName("width")
    val width: Double,

    @SerializedName("height")
    val height: Double,

    @SerializedName("depth")
    val depth: Double
) : Serializable

data class Review(
    @SerializedName("rating")
    val rating: Int,

    @SerializedName("comment")
    val comment: String,

    @SerializedName("date")
    val date: String,

    @SerializedName("reviewerName")
    val reviewerName: String,

    @SerializedName("reviewerEmail")
    val reviewerEmail: String
) : Serializable
package id.ac.polbeng.projectuts.ui.dashboard

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import id.ac.polbeng.projectuts.R
import id.ac.polbeng.projectuts.model.ProductResponse
import id.ac.polbeng.projectuts.network.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DashboardFragment : Fragment() {

    private lateinit var rvData: RecyclerView
    private lateinit var progressBar: ProgressBar

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val root = inflater.inflate(R.layout.fragment_dashboard, container, false)

        rvData = root.findViewById(R.id.rvData)
        progressBar = root.findViewById(R.id.progressBar)

        rvData.layoutManager = LinearLayoutManager(requireContext())

        // Panggil fungsi untuk mengambil data produk dari API
        fetchProducts()

        return root
    }

    private fun fetchProducts() {
        // Tampilkan ProgressBar dan sembunyikan RecyclerView saat loading
        progressBar.visibility = View.VISIBLE

        ApiConfig.instance.getProducts(limit = 25).enqueue(object : Callback<ProductResponse> {
            override fun onResponse(call: Call<ProductResponse>, response: Response<ProductResponse>) {
                // Sembunyikan ProgressBar setelah data berhasil diterima
                progressBar.visibility = View.GONE

                if (response.isSuccessful) {
                    val productList = response.body()?.products ?: emptyList()

                    // Hubungkan data dari API ke ProductAdapter dan arahkan ke DetailProductActivity saat diklik
                    val adapter = ProductAdapter(productList) { product ->
                        val intent = Intent(requireContext(), DetailProductActivity::class.java).apply {
                            putExtra(DetailProductActivity.EXTRA_PRODUCT, product)
                        }
                        startActivity(intent)
                    }
                    rvData.adapter = adapter
                } else {
                    Toast.makeText(requireContext(), "Gagal memuat data: ${response.message()}", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<ProductResponse>, t: Throwable) {
                // Sembunyikan ProgressBar jika terjadi error koneksi
                progressBar.visibility = View.GONE
                Toast.makeText(requireContext(), "Koneksi error: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}